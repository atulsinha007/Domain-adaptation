import os
import pandas as pd
import random
import numpy as np
import pickle

rng = random
pstri = './'
path = 'pickle_jar/'
assert (os.path.isfile(os.path.join(pstri + path, 'rest_data.pickle')))
fs = open(pstri + "pickle_jar/rest_data.pickle", "rb")
source_feat_mat, source_label_lis_num_arr = pickle.load(fs)
print(source_feat_mat.shape)
fs.close()
dum_arr = source_label_lis_num_arr.reshape((source_label_lis_num_arr.shape[0], 1))
clumped_arr = np.concatenate((source_feat_mat, dum_arr), axis=1)
numlis = np.arange(clumped_arr.shape[0])
ann = source_feat_mat.shape[0]
print(clumped_arr[:3])
rng.shuffle(numlis)
clumped_arr = clumped_arr[numlis]
clumped_train = clumped_arr[:]

assert (os.path.isfile(os.path.join(pstri + path, 'test_data.pickle')))
fs = open(pstri + "pickle_jar/test_data.pickle", "rb")
source_feat_mat, source_label_lis_num_arr = pickle.load(fs)
print(source_feat_mat.shape)
fs.close()
dum_arr = source_label_lis_num_arr.reshape((source_label_lis_num_arr.shape[0], 1))
clumped_arr = np.concatenate((source_feat_mat, dum_arr), axis=1)
numlis = np.arange(clumped_arr.shape[0])
ann = source_feat_mat.shape[0]
print(clumped_arr[:3])
rng.shuffle(numlis)
clumped_arr = clumped_arr[numlis]
clumped_test = clumped_arr[:]

assert (os.path.isfile(os.path.join(pstri + path, 'rest_eq_data.pickle')))
fs = open(pstri + "pickle_jar/rest_eq_data.pickle", "rb")
source_feat_mat, source_label_lis_num_arr = pickle.load(fs)
print(source_feat_mat.shape)
fs.close()
dum_arr = source_label_lis_num_arr.reshape((source_label_lis_num_arr.shape[0], 1))
clumped_arr = np.concatenate((source_feat_mat, dum_arr), axis=1)
numlis = np.arange(clumped_arr.shape[0])
ann = source_feat_mat.shape[0]
print(clumped_arr[:3])
rng.shuffle(numlis)
clumped_arr = clumped_arr[numlis]
clumped_train_eq = clumped_arr[:]

assert (os.path.isfile(os.path.join(pstri + path, 'test_eq_data.pickle')))
fs = open(pstri + "pickle_jar/test_eq_data.pickle", "rb")
source_feat_mat, source_label_lis_num_arr = pickle.load(fs)
print(source_feat_mat.shape)
fs.close()
dum_arr = source_label_lis_num_arr.reshape((source_label_lis_num_arr.shape[0], 1))
clumped_arr = np.concatenate((source_feat_mat, dum_arr), axis=1)
numlis = np.arange(clumped_arr.shape[0])
ann = source_feat_mat.shape[0]
print(clumped_arr[:3])
rng.shuffle(numlis)
clumped_arr = clumped_arr[numlis]
clumped_test_eq = clumped_arr[:]


def give_train_data(ratio_lis = [0.8, 0.2]):
	'''
		returns two tuples each tuple has one array as feature set and other as column arrray of numerical labels
		this one is for source
	'''
	n = len(clumped_train)
	nf_train = int(ratio_lis[0]*n)
	#nf_valid = int(ratio_lis[1]*n)
	# print(aann)
	train_setx = clumped_train[:nf_train, :-1] # tuple of two shared variable of array
	train_sety = clumped_train[:nf_train, -1:]
	valid_setx = clumped_train[nf_train:, :-1 ]
	valid_sety = clumped_train[nf_train:, -1: ]

	return train_setx, train_sety, valid_setx, valid_sety
def give_test_data():
	test_setx = clumped_test[:,:-1]
	test_sety = clumped_test[:, -1:]
	return test_setx, test_sety
def give_data():
	tuptr = give_train_data()
	tupte = give_test_data()
	return ( tuptr[0], tuptr[1]), ( tuptr[2], tuptr[3]), tupte

def give_train_data_eq(ratio_lis = [0.8, 0.2]):
	'''
		returns two tuples each tuple has one array as feature set and other as column arrray of numerical labels
		this one is for source
	'''
	n = len(clumped_train_eq)
	nf_train = int(ratio_lis[0]*n)
	#nf_valid = int(ratio_lis[1]*n)
	# print(aann)
	train_setx = clumped_train_eq[:nf_train, :-1] # tuple of two shared variable of array
	train_sety = clumped_train_eq[:nf_train, -1:]
	valid_setx = clumped_train_eq[nf_train:, :-1 ]
	valid_sety = clumped_train_eq[nf_train:, -1: ]

	return train_setx, train_sety, valid_setx, valid_sety
def give_test_data_eq():
	test_setx = clumped_test_eq[:,:-1]
	test_sety = clumped_test_eq[:, -1:]
	return test_setx, test_sety
def give_data_eq():
	tuptr = give_train_data_eq()
	tupte = give_test_data_eq()
	return ( tuptr[0], tuptr[1]), ( tuptr[2], tuptr[3]), tupte

def main():
	print("here", give_data()[0][0][:10])
	print("here", give_data()[0][1][:10])
