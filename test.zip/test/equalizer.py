import cv2
import numpy as np
from os import listdir
from os.path import isfile, join
import os
import re
dir_lis = ['00023966', '00005381', '00021510']
base_dir = './DNIM/Image/'
def equalize(dir_lis, base_dir):
	for dire in dir_lis:
		base = base_dir+dire+'/'+dire+'_rest'+'/'
		files = [f for f in listdir(base) if (isfile(join(base, f)) and re.match(".*\.jpg", f))]
		new_dir = base_dir+dire+'/'+dire+'_rest_eq/'
		if not os.path.isdir(new_dir):
			os.mkdir(new_dir)
		for i in range(len(files)):
			img = cv2.imread(base+files[i],0)
			#print(type(img))
			equ = cv2.equalizeHist(img)
			#res = np.hstack((img,equ)
			print(new_dir + files[i])
			cv2.imwrite(new_dir+files[i],equ)
	for dire in dir_lis:
		base = base_dir+dire+'/'+dire+'_test'+'/'
		files = [f for f in listdir(base) if isfile(join(base, f)) and re.match(".*\.jpg", f)]
		new_dir = base_dir+dire+'/'+dire+'_test_eq/'
		if not os.path.isdir(new_dir):
			os.mkdir(new_dir)
		for i in range(len(files)):
			img = cv2.imread(base+files[i],0)
			#print(type(img))
			equ = cv2.equalizeHist(img)
			#res = np.hstack((img,equ)
			print(new_dir+files[i])
			cv2.imwrite(new_dir+files[i],equ)
if __name__ == '__main__':
	equalize(dir_lis, base_dir)


